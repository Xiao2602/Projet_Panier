package org.example;

public class CartItem {
    //Encapsulation pour garder les valeurs de produits et quantité
    private Product product;
    private int quantity;

    // Constructeur
    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    // Getter pour le produit
    public Product getProduct() {
        return product;
    }

    // Getter pour la quantité
    public int getQuantity() {
        return quantity;
    }

    // Setter pour la quantité
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
