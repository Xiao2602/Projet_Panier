package org.example;

public class Product {
    // Attributs du produit
    private int id;             // Identifiant unique du produit
    private String name;        // Nom du produit
    private double price;       // Prix unitaire du produit
    private String category;    // Catégorie du produit (ex: électronique, vêtement...)
    private int quantity;       // Quantité disponible en stock

    //Constructeur pour créer un nouveau produit avec ses propriétés
    public Product(int id, String name, double price, String category, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
        this.quantity = quantity;
    }

    // Méthodes d'accès aux attributs (getters)

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    //Réduit la quantité disponible en stock et se fait uniquement si le stock est suffisant.
    public void reduceQuantity(int quantity) {
        if (this.quantity >= quantity) {
            this.quantity -= quantity;
        }
    }

    //Retourne une représentation textuelle du produit
    @Override
    public String toString() {
        return "ID: " + id + " | Nom: " + name + " | Prix: " + price + "€ | Catégorie: " + category + " | Quantité disponible: " + quantity;
    }
}
