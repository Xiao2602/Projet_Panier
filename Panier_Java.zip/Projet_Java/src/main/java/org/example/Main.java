package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    // Liste des articles dans le panier (chaque élément contient un produit et une quantité)
    private static ArrayList<CartItem> cartItems = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stock stock = new Stock(); // Stock cntenant tous les produits disponibles

        // Message de bienvenue
        System.out.print("\n");
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║        Bienvenue dans notre boutique.        ║");
        System.out.println("║     Créez votre panier et profitez des       ║");
        System.out.println("║         promotions sur nos produits !        ║");
        System.out.println("╚══════════════════════════════════════════════╝");

        // Boucle du menu principal
        while (true) {
            // Affichage des options disponibles
            System.out.println("\n==================================================");
            System.out.println("1. Afficher les produits");
            System.out.println("2. Ajouter au panier");
            System.out.println("3. Voir le reçu");
            System.out.println("4. Voir le panier");
            System.out.println("5. Vider le panier");
            System.out.println("6. Retirer un produit du panier");
            System.out.println("7. Voir les promotions");
            System.out.println("8. Enregistrer le panier dans un fichier");
            System.out.println("9. Charger un panier depuis un fichier");
            System.out.println("10. Quitter");
            System.out.println("==================================================");
            System.out.print("\nChoisissez une option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    // Affiche les produits disponibles dans le stock
                    System.out.println("\nProduits disponibles :");
                    for (Product product : stock.getProducts()) {
                        System.out.println(product);
                    }
                    break;

                case 2:
                    // Ajouter un produit au panier
                    System.out.print("\nEntrez l'ID du produit à ajouter au panier: ");
                    int productId = scanner.nextInt();
                    Product selectedProduct = stock.getProductById(productId);
                    if (selectedProduct != null) {
                        System.out.print("Entrez la quantité: ");
                        int quantity = scanner.nextInt();
                        try {
                            if (quantity <= 0) throw new InvalidQuantityException("Quantité invalide.");
                            cartItems.add(new CartItem(selectedProduct, quantity));
                            stock.reduceStock(productId, quantity); // Mise à jour du stock
                            System.out.println("\n" + selectedProduct.getName() + " ajouté au panier.");
                        } catch (InvalidQuantityException e) {
                            System.out.println(e.getMessage());
                        }
                    } else {
                        System.out.println("\nProduit indisponible.");
                    }
                    break;

                case 3:
                    // Affiche le reçu avec les promotions appliquées
                    printReceipt();
                    break;

                case 4:
                    // Affiche les produits actuellement dans le panier
                    if (cartItems.isEmpty()) {
                        System.out.println("\nLe panier est vide!");
                    } else {
                        printCartContents();
                    }
                    break;

                case 5:
                    // Vide complètement le panier
                    cartItems.clear();
                    System.out.println("\nLe panier a été vidé.");
                    break;

                case 6:
                    // Supprime un produit spécifique du panier
                    if (cartItems.isEmpty()) {
                        System.out.println("\nLe panier est déjà vide!");
                    } else {
                        System.out.print("\nEntrez l'ID du produit à retirer du panier: ");
                        int removeProductId = scanner.nextInt();
                        CartItem toRemove = null;
                        for (CartItem item : cartItems) {
                            if (item.getProduct().getId() == removeProductId) {
                                toRemove = item;
                                break;
                            }
                        }
                        if (toRemove != null) {
                            cartItems.remove(toRemove);
                            System.out.println("Le produit '" + toRemove.getProduct().getName() + "' a été retiré du panier.");
                        } else {
                            System.out.println("Produit introuvable dans le panier.");
                        }
                    }
                    break;

                case 7:
                    // Affiche la liste des promotions disponibles
                    System.out.println("\n═══════════ Promotions Disponibles ═══════════");
                    System.out.println("1. -10% sur les produits de la catégorie 'Électronique' (si l'on prend + de 3 articles)");
                    System.out.println("2. -15% sur les produits de la catégorie 'Électronique' (quand le prix dépasse 100€)");
                    System.out.println("3. -20% sur les vêtements si vous en achetez 4 ou plus");
                    System.out.println("4. -5€ sur les accessoires coûtant plus de 30€");
                    System.out.println("5. -50% sur les boissons à partir de 6 unités");
                    System.out.println("6. -20% sur 'Roman fantasy' si vous en achetez 3 ou plus ");
                    System.out.println("══════════════════════════════════════════════");
                    break;

                case 8:
                    // Sauvegarde du panier dans un fichier texte
                    System.out.print("\nEntrez le nom du fichier pour sauvegarder le panier (sans extension): ");
                    String filename = scanner.nextLine();
                    try (PrintWriter writer = new PrintWriter(filename + ".txt")) {
                        for (CartItem item : cartItems) {
                            writer.println(item.getProduct().getId() + "," + item.getQuantity());
                        }
                        System.out.println("Panier sauvegardé dans " + filename + ".txt");
                    } catch (IOException e) {
                        System.out.println("Erreur lors de la sauvegarde du panier.");
                    }
                    break;

                case 9:// Chargement d’un panier depuis un fichier
                    while (true) {
                        System.out.print("\nEntrez le nom du fichier à charger (sans extension): ");
                        String loadFilename = scanner.nextLine();
                        File file = new File(loadFilename + ".txt");

                        if (file.exists()) {
                            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                                cartItems.clear();
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    String[] parts = line.split(",");
                                    int id = Integer.parseInt(parts[0]);
                                    int quantity = Integer.parseInt(parts[1]);
                                    Product p = stock.getProductById(id);
                                    if (p != null) {
                                        cartItems.add(new CartItem(p, quantity));
                                    }
                                }
                                System.out.println("Panier chargé depuis " + file.getName());
                            } catch (IOException e) {
                                System.out.println("Erreur de lecture du fichier.");
                            } catch (Exception e) {
                                System.out.println("Erreur lors du chargement : données corrompues ?");
                            }
                            break;
                        } else {
                            System.out.println("Fichier introuvable. Essayez encore.");
                        }
                    }
                    break;

                case 10:
                    // Quitte le programme proprement
                    System.out.println("\nMerci de votre visite, à bientôt !");
                    scanner.close();
                    return;

                default:
                    // Gère une option non valide
                    System.out.println("\nOption invalide, veuillez choisir une option correcte.");
                    break;
            }
        }
    }

    // Affichage des articles avec promotions éventuelles
    public static void printReceipt() {
        if (cartItems.isEmpty()) {
            System.out.println("Le panier est vide.");
            return;
        }

        double totalPriceBeforeDiscount = 0;
        double totalPriceAfterDiscount = 0;

        // Liste regroupant les articles identiques (si l'on prend une certaine quantité d'un produit et que l'on reprend une nouvelle fois celui ci)
        ArrayList<CartItem> mergedItems = new ArrayList<>();

        for (CartItem item : cartItems) {
            Product product = item.getProduct();
            int quantity = item.getQuantity();
            boolean merged = false;

        // Regroupe les articles par ID pour ne pas afficher plusieurs fois le même produit
            for (CartItem mergedItem : mergedItems) {
                if (mergedItem.getProduct().getId() == product.getId()) {
                    mergedItem.setQuantity(mergedItem.getQuantity() + quantity);
                    merged = true;
                    break;
                }
            }

            if (!merged) {
                mergedItems.add(new CartItem(product, quantity));
            }
        }

        // Génère un reçu avec les réductions appliquées
        System.out.println("\n--- Reçu ---");
        for (CartItem item : mergedItems) {
            Product product = item.getProduct();
            int quantity = item.getQuantity();
            double originalPrice = product.getPrice();
            double totalBeforeDiscount = originalPrice * quantity;
            double discountedPrice = Discount.applyBestDiscount(product, quantity);
            double itemTotal = discountedPrice * quantity;

            totalPriceBeforeDiscount += totalBeforeDiscount;
            totalPriceAfterDiscount += itemTotal;

            // Affiche la promotion si elle s'applique
            String discountNote = (discountedPrice < originalPrice)
                    ? " <== Promotion : " + Discount.getAppliedDiscountDescription(product, quantity)
                    : "";

            System.out.println("Produit: " + product.getName()
                    + " | Quantité: " + quantity
                    + " | Prix unitaire: " + originalPrice + "€"
                    + " | Total: " + itemTotal + "€"
                    + discountNote);
        }

        // Affiche le total final
        if (totalPriceBeforeDiscount > totalPriceAfterDiscount) {
            System.out.println("\nTotal avant la promotion: " + totalPriceBeforeDiscount + "€");
            System.out.println("\nTotal après réduction: " + totalPriceAfterDiscount + "€");
        } else {
            System.out.println("\nTotal à payer (sans promotion): " + totalPriceBeforeDiscount + "€");
        }
    }

    // Affiche simplement les produits dans le panier
    public static void printCartContents() {
        System.out.println("\n--- Contenu du Panier ---");
        for (CartItem item : cartItems) {
            Product product = item.getProduct();
            System.out.println("Produit: " + product.getName() + " | Quantité: " + item.getQuantity());
        }
    }
}
