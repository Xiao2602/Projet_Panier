package org.example;

import java.util.ArrayList;

public class Stock {
    private ArrayList<Product> products;

    public Stock() {
        products = new ArrayList<>();
        // Initialisation avec quelques produits
        products.add(new Product(1, "Laptop", 1200, "Électronique", 150));
        products.add(new Product(2, "Smartphone", 800, "Électronique", 130));
        products.add(new Product(6, "Tablette", 750, "Électronique", 140));

        products.add(new Product(4, "T-shirt", 20, "Vêtements", 30));
        products.add(new Product(5, "Jeans", 45, "Vêtements", 25));
        products.add(new Product(7, "Short", 40, "Vêtements", 40));

        products.add(new Product(3, "Casquette", 25, "Accessoires", 20));
        products.add(new Product(14, "Sac à dos", 40, "Accessoires", 30));
        products.add(new Product(15, "Lunettes de soleil", 30, "Accessoires", 25));

        products.add(new Product(11, "Champagne", 30, "Boisson", 20));
        products.add(new Product(12, "Jus d'orange", 4.80, "Boisson", 15));
        products.add(new Product(13, "Bouteille d’eau", 5, "Boisson", 10));

        products.add(new Product(8, "Roman historique", 15, "Livres", 20));
        products.add(new Product(9, "Roman biographique", 10, "Livres", 10));
        products.add(new Product(10, "Roman fantasy", 18, "Livres", 35));
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public Product getProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null; // Retourne null si le produit n'est pas trouvé
    }

    public void reduceStock(int id, int quantity) {
        Product product = getProductById(id);
        if (product != null) {
            product.reduceQuantity(quantity);
        }
    }
}
