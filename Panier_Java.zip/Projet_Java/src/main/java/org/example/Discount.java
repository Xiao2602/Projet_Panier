package org.example;

public class Discount {

    //Retourne une description textuelle de la promotion appliquée à un produit selon sa catégorie, son prix et la quantité achetée.
    public static String getAppliedDiscountDescription(Product product, int quantity) {
        double basePrice = product.getPrice();

        // Réductions spécifiques à la catégorie "Électronique"
        if (product.getCategory().equalsIgnoreCase("Électronique")) {
            if (basePrice > 100) return "-15% sur Électronique (>100€)";
            if (quantity >= 3) return "-10% sur Électronique (3+)";
        }

        // Réduction sur les vêtements si on en prend au moins 4
        if (product.getCategory().equalsIgnoreCase("Vêtements") && quantity >= 4) {
            if (applyDiscount(product, 20) < basePrice) return "-20% sur Vêtements (4+)";
        }

        // Réduction fixe de 5€ sur les accessoires de plus de 30€
        if (product.getCategory().equalsIgnoreCase("Accessoires") && basePrice > 30) {
            if ((basePrice - 5) < basePrice) return "-5€ sur Accessoires (>30€)";
        }

        // Boissons à -50% si on en prend 6 ou plus
        if (product.getCategory().equalsIgnoreCase("Boisson") && quantity >= 6) {
            if (basePrice * 0.5 < basePrice) return "-50% sur Boissons (6+)";
        }

        // Réduction spécifique pour un produit nommé "Roman fantasy"
        if (product.getName().equalsIgnoreCase("Roman fantasy") && quantity >= 3) {
            if (applyDiscount(product, 20) < basePrice) return "-20% sur Roman fantasy (3+)";
        }

        // Réduction par défaut de 15% si on achète au moins 5 unités
        if (quantity >= 5) {
            if (applyDiscount(product, 15) < basePrice) return "-15% sur quantité (5+)";
        }

        return "Aucune promotion appliquée";
    }

    // Formule de réduction d'un produit.
    public static double applyDiscount(Product product, double discountPercentage) {
        double discount = product.getPrice() * discountPercentage / 100;
        return product.getPrice() - discount;
    }

    //
    public static double applyBestDiscount(Product product, int quantity) {
        double basePrice = product.getPrice();
        double bestPrice = basePrice;

        // 1. Électronique : 15% si >100€
        if (product.getCategory().equalsIgnoreCase("Électronique")) {
            if (basePrice > 100) {
                double promo = applyDiscount(product, 15);
                if (promo < bestPrice) bestPrice = promo;
            } else if (quantity >= 3) {
        // 2. Électronique : 10% si quantité >= 3
                double promo = applyDiscount(product, 10);
                if (promo < bestPrice) bestPrice = promo;
            }
        }

        // 3. Vêtements : -20% si quantité >= 4
        if (product.getCategory().equalsIgnoreCase("Vêtements") && quantity >= 4) {
            double promo = applyDiscount(product, 20);
            if (promo < bestPrice) bestPrice = promo;
        }

        // 4. Accessoires : -5€ si prix > 30€
        if (product.getCategory().equalsIgnoreCase("Accessoires") && basePrice > 30) {
            double promo = basePrice - 5;
            if (promo < bestPrice) bestPrice = promo;
        }

        // 5. Boissons : -50% si quantité >= 6
        if (product.getCategory().equalsIgnoreCase("Boisson") && quantity >= 6) {
            double promo = basePrice * 0.5;
            if (promo < bestPrice) bestPrice = promo;
        }

        // 6. Livre spécifique : "Roman fantasy" -20% si 3 ou +
        if (product.getName().equalsIgnoreCase("Roman fantasy") && quantity >= 3) {
            double promo = applyDiscount(product, 20);
            if (promo < bestPrice) bestPrice = promo;
        }

        return bestPrice;
    }
}
